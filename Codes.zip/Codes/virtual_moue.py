import os
import cv2
import numpy as np
from utils import *
import pyautogui
from detector_torch import YOLOHandDetectorTorch
import time

##########################
#1190x1024
wCam, hCam = 1200, 1000
frameR = 100  # Frame Reduction
smoothening = 5
pTime = 0
plocX, plocY = 0, 0
clocX, clocY = 0, 0
##########################

kpts_score_threshold = 0.50
thumb_index_threshold = 80.0
smoothing_thres = 5.0
sensitivity_multiplier = 3

detector = YOLOHandDetectorTorch('/Users/mominaali/Desktop/PhD MTSU/Research Work/mmpose_2/code-and-model-files/ckpt_best.pth')

cap = cv2.VideoCapture(1)
cap.set(3, wCam)
cap.set(4, hCam)
# Get screen x and y coordinates.
screen_x, screen_y = pyautogui.size()
screen_cx, screen_cy = screen_x // 2, screen_y // 2


# Initialize flags to indicate whether gesture control should be enabled.
gesture_control_enabled = False
palm_centroid = None
prev_x = prev_y = None
clicked_text = ''

RECT_COLORS = [(255, 0, 0), (0, 0, 0), (0, 0, 255)]


##########################  
debug = False 

move_controll =True
click_controll=True 

images_path = './testData_Home'
images_name = os.listdir(images_path)
images_name = list(filter(lambda x: x.endswith('.jpg') or x.endswith('.png'), images_name))
print('[images_name]', len(images_name))
img_idx = 0
##########################

# Run the loop.
while True:
    # Read the return flag and the frame.
    if debug:
        ret, frame = True, cv2.imread(os.path.join(images_path, images_name[img_idx]))
        img_idx = (img_idx + 1) % len(images_name)
        frame=cv2.resize(frame,(1552,1000))
    else:
        ret, frame = cap.read()
        #=====================================
        resize_img=cv2.resize(frame,(1552,1000))    
        height, width = resize_img.shape[:2]
        crop_height = 1000
        crop_width = 1552
        top = (height - crop_height) // 2
        bottom = (top + crop_height) + 20
        
        # Crop the image
        cropped_img = resize_img[top:bottom, 0:crop_width]

        frame = cropped_img
        #============================================++++++++++++++++++++++++++

    # If no frame/ invalid frame was returned, break the loop.
    if not ret:
        break

    frame = frame[:, ::-1, :]

    # Get the frame height and width.
    frame_w, frame_h = frame.shape[0], frame.shape[1]

    # Predict the keypoints
    detected_hands, img = detector.detectHands(frame, verbose=False)
    if(len(detected_hands)<1):
        print("No PRediciton Found.")
        if cv2.waitKey(100) == ord('q'):
            break
        continue
    bbox, score, kpts ,edge_links= detected_hands[0]
    keypoint_scores = kpts[:, 2].ravel()
    kpts = kpts[:, [0, 1]]
    kpts_scores_mean = np.mean(keypoint_scores)
    # Debug: Check if the keypoints are correct
    for idx, (kp, score) in enumerate(zip(kpts, keypoint_scores)):
        print(f"Keypoint {idx}: Position = ({kp[0]}, {kp[1]}), Score = {score}")
    
     

    output_frame = frame.copy()

       # Draw keypoints on the frame
    for idx, (kp, score) in enumerate(zip(kpts, keypoint_scores)):
        if score > kpts_score_threshold:
            cv2.circle(output_frame, (int(kp[0]), int(kp[1])), 5, (0, 255, 0), cv2.FILLED)  # Green for detected keypoints
            cv2.putText(output_frame, str(idx), (int(kp[0]), int(kp[1])), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 1, cv2.LINE_AA)


    # Calculate the distance between keypoints 8 and 12
    if keypoint_scores[8] > kpts_score_threshold and keypoint_scores[12] > kpts_score_threshold:
        x8, y8 = kpts[8]
        x12, y12 = kpts[12]
        distance = np.sqrt((x12 - x8)**2 + (y12 - y8)**2)
        distance_text = f"Distance: {distance:.2f}"

        # Draw the distance on the frame
        cv2.putText(output_frame, distance_text, (20, 60), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 255, 0), 1, cv2.LINE_AA)
    

    # manually draw all keypoints
    if kpts_scores_mean >= kpts_score_threshold:
        for kpt in kpts:
            cv2.circle(output_frame, (int(kpt[0]), int(kpt[1])), 5, (0, 0, 0), cv2.FILLED)
        for k, pair in enumerate(edge_links):
                        pt1 = kpts[pair[0]]
                        pt2 = kpts[pair[1]]
                        cv2.line(output_frame, pt1[:2].astype(np.int64), pt2[:2].astype(np.int64), color=RECT_COLORS[1], thickness=1, lineType=cv2.LINE_AA)
    # Draw text on the screen.
    output_frame = cv2.putText(output_frame, 'Gesture Control:', (20, 20), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
    output_frame = cv2.putText(output_frame, 'Action:', (20, 40), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
    if not gesture_control_enabled:
        output_frame = cv2.putText(output_frame, 'Disabled', (170, 20), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 255), 1, cv2.LINE_AA)
    else:
        output_frame = cv2.putText(output_frame, 'Enabled', (170, 20), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 255, 0), 1, cv2.LINE_AA)

    # Get the output frame with the rectangle and the rect points (corners)
    if not gesture_control_enabled:
        output_frame, rect_pts = draw_gesture_control_roi(output_frame, 0.5)
    else:
        # draw rectangle to control mouse movement
        cv2.rectangle(output_frame, (frameR, frameR), (wCam - frameR, hCam - frameR), (255, 0, 255), 2)

    if keypoint_scores[8] > kpts_score_threshold:
        cv2.circle(output_frame, (int(kpts[8][0]), int(kpts[8][1])), 15, (255, 0, 0), cv2.FILLED)
    if keypoint_scores[12] > kpts_score_threshold:
        cv2.circle(output_frame, (int(kpts[12][0]), int(kpts[12][1])), 15, (0, 0, 255), cv2.FILLED)

    # Only process this frame if the mean score for all keypoints is greater than the threshold.
    if kpts_scores_mean >= kpts_score_threshold:

        # Draw the keypoints with ids on the frame and get the distance between the thumb and index finger, 
        output_frame, index_middle_top_distance = draw_keypoint_ids(output_frame, kpts)
        output_frame = output_frame.copy()

        # Draw the gesture control rectangle on the screen if gesture control has not been enabled.
        # Check if the palm is inside the gesture control
        if not gesture_control_enabled:

            palm_inside_gesture_roi = enclosed_in(np.array(kpts), rect_pts)

            # If the predicted keypoints for the palm are all inside the rectangle, we can start gesture control.
            if palm_inside_gesture_roi:

                # Get the centroid of the keypoints
                palm_centroid = get_centroid_from_pts(kpts)
                print('Palm centroid is:', palm_centroid)

                # Set the position of the mouse cursor to the center of the screen.
                if move_controll:
                    pyautogui.moveTo(screen_cx, screen_cy)

                # Enable gesture control
                gesture_control_enabled = True

        # Check if gesture control is enabled.
        if gesture_control_enabled:

            output_frame = cv2.circle(output_frame, (int(kpts[8][0]), int(kpts[8][1])), 15, (255, 0, 0), cv2.FILLED)
            output_frame = cv2.circle(output_frame, (int(kpts[12][0]), int(kpts[12][1])), 15, (0, 0, 255), cv2.FILLED)

            # Get the tip of the index finger
            x1, y1 = int(kpts[8][0]), int(kpts[8][1])

            # make sure then x1 is within bounds (frameR, wCam - frameR)
            x1 = min(max(x1, frameR), wCam - frameR)
            # make sure then y1 is within bounds (frameR, hCam - frameR)
            y1 = min(max(y1, frameR), hCam - frameR)

            # Convert Coordinates
            x2 = np.interp(x1, (frameR, wCam - frameR), (0, screen_x))
            y2 = np.interp(y1, (frameR, hCam - frameR), (0, screen_y))
            # Smoothen Values
            clocX = plocX + (x2 - plocX) / smoothening
            clocY = plocY + (y2 - plocY) / smoothening
            # Move Mouse
            if move_controll:
                pyautogui.moveTo(clocX, clocY)
            plocX, plocY = clocX, clocY

            # If the distance between the thumb top and index finger top is less than the threshold, press mouse click.
            if index_middle_top_distance < thumb_index_threshold:
                output_frame = cv2.putText(output_frame, 'CLICK', (80, 40), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 255, 0), 1, cv2.LINE_AA)
                if click_controll:
                    pyautogui.click()
            else:
                output_frame = cv2.putText(output_frame, 'CONTROLLING MOUSE', (80, 40), cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
        else:
            output_frame = cv2.putText(output_frame, 'IDLE', (80, 40), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 255), 1, cv2.LINE_AA)
    else:
        output_frame = cv2.putText(output_frame, 'IDLE', (80, 40), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 255), 1, cv2.LINE_AA)

    # Display
    cv2.imshow('res', output_frame)

    if cv2.waitKey(100) == ord('q'):
        break

    cTime = time.time()
    fps = 1/ (cTime -pTime)
    pTime = cTime

    cv2.putText(img, str(int(fps)), (500,500),cv2.FONT_HERSHEY_PLAIN,3,(255,0,0),3)

cv2.destroyAllWindows()





