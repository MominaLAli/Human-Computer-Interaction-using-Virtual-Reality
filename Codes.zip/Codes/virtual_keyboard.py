import os
import cv2
import numpy as np
import pyautogui
from detector_torch import YOLOHandDetectorTorch

def virtual_keyboard_manager(image, clicked_text, kpts, kpts_scores, kpts_score_threshold, margin_x=10, margin_y=10, key_width=100, key_height=50, visibility=1.0):
    keyboard_chars = [
        ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
        ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
        ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', '"'],
        ['Z', 'X', 'C', 'V', 'B', 'N', 'M', 'BK', '.', ',']
    ]
    h, w, _ = image.shape
    keyboard_img = np.zeros_like(image, dtype=image.dtype)
    keyboard_width = len(keyboard_chars[0]) * key_width
    keyboard_height = len(keyboard_chars) * key_height
    start_x = int((w - keyboard_width) * 0.5)
    start_y = int((h - keyboard_height) * 0.15)
    for i, row_chars in enumerate(keyboard_chars):
        for j, char in enumerate(row_chars):
            key_img = np.zeros_like(image, dtype=image.dtype)
            x1 = int(start_x + int(j * key_width) + margin_x / 2)
            y1 = int(start_y + int(i * key_height) + margin_y / 2)
            x2 = int(x1 + key_width - margin_x / 2)
            y2 = int(y1 + key_height - margin_y / 2)
            if char == 'BK':
                x_text = int(x1 + key_width/2 - 10)
            else:
                x_text = int(x1 + key_width/2 - 5)
            y_text = int(y1 + key_height/2 + 5)

            # check if index finger tip is within current key boundary
            condition_index_tip = kpts_scores[8] > kpts_score_threshold and x1 <= kpts[8][0] <= x2 and y1 <= kpts[8][1] <= y2
            # check if middle finger tip is within current key boundary
            condition_middle_tip = kpts_scores[12] > kpts_score_threshold and x1 <= kpts[12][0] <= x2 and y1 <= kpts[12][1] <= y2

            if condition_index_tip:
                if condition_middle_tip:
                    # if both index and middle finger tip is on the key then highlight it and click it
                    cv2.rectangle(key_img, (x1, y1), (x2, y2), (255, 0, 0), -1)
                    cv2.rectangle(key_img, (x1, y1), (x2, y2), (255, 255, 255), 2)
                    cv2.putText(key_img, str(char), (x_text, y_text), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 2, cv2.LINE_AA)    
                    keyboard_img = cv2.addWeighted(keyboard_img, 1.0, key_img, visibility*10, gamma=0)
                    if char == 'BK':
                        clicked_text = clicked_text[:-1]
                    else:
                        clicked_text += char
                else:
                    # if only index finger tip is on the key then highlight it
                    cv2.rectangle(key_img, (x1, y1), (x2, y2), (255, 0, 255), -1)
                    cv2.rectangle(key_img, (x1, y1), (x2, y2), (255, 255, 255), 2)
                    cv2.putText(key_img, str(char), (x_text, y_text), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 2, cv2.LINE_AA)
                    keyboard_img = cv2.addWeighted(keyboard_img, 1.0, key_img, visibility*10, gamma=0)
            else:
                # if no finger tip on the key then draw it normally
                cv2.rectangle(key_img, (x1, y1), (x2, y2), (0, 0, 0), -1)
                cv2.rectangle(key_img, (x1, y1), (x2, y2), (255, 255, 255), 2)
                cv2.putText(keyboard_img, str(char), (x_text, y_text), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2, cv2.LINE_AA)
                keyboard_img = cv2.addWeighted(keyboard_img, 1.0, key_img, visibility, gamma=0)

    image = cv2.addWeighted(image, 0.75, keyboard_img, visibility, gamma=0)

    return image, clicked_text

##########################
wCam, hCam = 1552, 1552
frameR = 100  # Frame Reduction
smoothening = 7
pTime = 0
plocX, plocY = 0, 0
clocX, clocY = 0, 0
##########################

kpts_score_threshold = 0.50
thumb_index_threshold = 50.0
smoothing_thres = 1.0
sensitivity_multiplier = 10

detector = YOLOHandDetectorTorch('/Users/mominaali/Desktop/PhD MTSU/Research Work/mmpose_2/code-and-model-files/ckpt_best.pth')

# The MMPoseInferencer API employs a lazy inference approach,
# creating a prediction generator when given input
cap = cv2.VideoCapture(1)
cap.set(3, wCam)
cap.set(4, hCam)
# Get screen x and y coordinates.
screen_x, screen_y = pyautogui.size()
screen_cx, screen_cy = screen_x // 2, screen_y // 2

# Initialize flags to indicate whether gesture control should be enabled.
gesture_control_enabled = False
palm_centroid = None
prev_x = prev_y = None
clicked_text = ''

##########################
debug = False
images_path = '/Users/mominaali/Desktop/PhD MTSU/Research Work/mmpose_2/code-and-model-files/testData_Home'
images_name = os.listdir(images_path)
images_name = list(filter(lambda x: x.endswith('.jpg') or x.endswith('.png'), images_name))
print('[images_name]', len(images_name))
img_idx = 0
##########################
RECT_COLORS = [(255, 0, 0), (0, 0, 0), (0, 0, 255)]
# Run the loop.
while True:

    if debug:
        ret, frame = True, cv2.imread(os.path.join(images_path, images_name[img_idx]))
        img_idx = (img_idx + 1) % len(images_name)
        frame=cv2.resize(frame,(1552,866))
    else:
        ret, frame = cap.read()
        
        
        #=====================================
        resize_img=cv2.resize(frame,(1552,1552))    
        # Define the crop area for 1000 x 558
        height, width = resize_img.shape[:2]
        crop_height = 866
        crop_width = 1552
        top = (height - crop_height) // 2
        bottom = top + crop_height
        
        # Crop the image
        cropped_img = resize_img[top:bottom, 0:crop_width]

        frame = cropped_img
        #============================================++++++++++++++++++++++++++

    # If no frame/ invalid frame was returned, break the loop.
    if not ret:
        break

    frame = frame[:, ::-1, :]

    # Get the frame height and width.
    frame_w, frame_h = frame.shape[0], frame.shape[1]

    # Predict the keypoints
    detected_hands, img = detector.detectHands(frame, verbose=False)
    if(len(detected_hands)<1):
        print("No PRediciton Found.")
        if cv2.waitKey(100) == ord('q'):
            break
        continue
    bbox, score, kpts ,edge_links= detected_hands[0]



    keypoint_scores = kpts[:, 2].ravel()

    # manually draw all keypoints
    output_frame = frame.copy()
    for kpt in kpts:
        cv2.circle(output_frame, (int(kpt[0]), int(kpt[1])), 5, (0, 0, 0), cv2.FILLED)
    
    for k, pair in enumerate(edge_links):
        pt1 = kpts[pair[0]]
        pt2 = kpts[pair[1]]
        cv2.line(output_frame, pt1[:2].astype(np.int64), pt2[:2].astype(np.int64), color=RECT_COLORS[1], thickness=1, lineType=cv2.LINE_AA)

    if keypoint_scores[8] > kpts_score_threshold:
        cv2.circle(output_frame, (int(kpts[8][0]), int(kpts[8][1])), 15, (255, 0, 0), cv2.FILLED)
    if keypoint_scores[12] > kpts_score_threshold:
        cv2.circle(output_frame, (int(kpts[12][0]), int(kpts[12][1])), 15, (0, 0, 255), cv2.FILLED)



    # Draw Virtual Keyboard and also manage key click based on hand keypoints
    output_frame, clicked_text = virtual_keyboard_manager(output_frame.copy(), clicked_text, kpts, keypoint_scores, kpts_score_threshold,key_height=100, key_width=150)
    print('[clicked_text]', clicked_text)
    cv2.putText(output_frame, clicked_text, (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2, cv2.LINE_AA)

    # Display
    resized_frame = cv2.resize(output_frame, (2*wCam, 2*hCam))  # Resize to double the original size
    cv2.imshow('res', output_frame)

    if cv2.waitKey(10) == ord('q'):
        break

cv2.destroyAllWindows()
