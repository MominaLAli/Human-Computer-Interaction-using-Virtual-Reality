import cv2
import numpy as np
import torch
from super_gradients.training import models
from super_gradients.training.metrics import PoseEstimationMetrics
from super_gradients.training.models.pose_estimation_models.yolo_nas_pose import YoloNASPosePostPredictionCallback

np.set_printoptions(precision=10, floatmode='fixed', suppress=True, threshold=50, edgeitems=10)


class YOLOHandDetectorTorch:
    def __init__(self, model_path='checkpoints/yolo_nas_n_5K.pth'):
        self.model =  models.get('yolo_nas_pose_n',
                        num_classes=21,
                        checkpoint_path=model_path)

        ckpt = torch.load(model_path, map_location='cpu')

        self.post_prediction_callback = YoloNASPosePostPredictionCallback(
            pose_confidence_threshold = 0.3,
            nms_iou_threshold = 0.7,
            pre_nms_max_predictions = 300,
            post_nms_max_predictions = 30,
        )

        self.metrics = PoseEstimationMetrics(
            num_joints =21,
            oks_sigmas = [0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1],
            max_objects_per_image = 30,
            post_prediction_callback = self.post_prediction_callback,
            iou_thresholds_to_report=[0.5, 0.75, 0.95],
        )


    def detectHands(self, frame : np.ndarray, verbose=False):
        TAG = '[YOLOHandDetector][detectHands]'
        # Check if frame is not empty
        detected_hands = []
        if frame is None:
            return detected_hands, frame

        # Resize frame to the required input size

        preds = self.model.predict(frame, conf=0.3)
        image = preds.image
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
        h, w, _ = image.shape

        RECT_COLORS = [(255, 0, 0), (0, 0, 0), (0, 0, 255)]

        for i in range(0, min(3, len(preds.prediction))):
            pose = preds.prediction.poses[i]
            # print('[pose]', pose.shape)
            bbox = preds.prediction.bboxes_xyxy[i]
            # print('[bbox]', bbox.shape)

            x1, y1, x2, y2 = bbox
            x1 = int(min(w, max(x1, 0)))
            y1 = int(min(h, max(y1, 0)))
            x2 = int(min(w, max(x2, 0)))
            y2 = int(min(h, max(y2, 0)))
            cv2.rectangle(image, (x1, y1), (x2, y2), RECT_COLORS[i], thickness=2, lineType=cv2.LINE_AA)

            for j, kpt in enumerate(pose):

                cv2.circle(image, kpt[:2].astype(np.int64), radius=4, color=RECT_COLORS[i], thickness=-1, lineType=cv2.LINE_AA)
            for k, pair in enumerate(preds.prediction.edge_links):
                pt1 = pose[pair[0]]
                pt2 = pose[pair[1]]
                cv2.line(image, pt1[:2].astype(np.int64), pt2[:2].astype(np.int64), color=RECT_COLORS[i], thickness=1, lineType=cv2.LINE_AA)
            

           
            #print(preds.prediction)
            detected_hands.append([[x1 , y1 , x2,y2], preds.prediction.scores, pose,preds.prediction.edge_links])

        return detected_hands, image
